/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;

import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JFrame;

public class RemoteProcessWrite implements Runnable {
	
	static PrintWriter out;
	int rateLimit;
	Socket socket =null;
	static int start =0;
	static UserKeyEnter user;
	static Viewer myViewer;
	static int screen_width;
	static int screen_height;
	static JFrame frame;
	static LocalView view;
	static boolean check ;
	
	RemoteProcessWrite(PrintWriter write,LocalView view2) {
		out = write;
		rateLimit=SimpleStream.rate;	
		check = false;
		screen_width = SimpleStream.screen_width;
		screen_height = SimpleStream.screen_height;
		myViewer = new Viewer(SimpleStream.screen_width,SimpleStream.screen_height);
		//System.out.print(screen_width);
		frame = new JFrame("SimpleStream Write Viewer");
		frame.setVisible(true);
		frame.setSize(screen_width, screen_height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		frame.add(myViewer);
		view = view2;
		ImageStream.setValues(screen_width, screen_height);
		
		//System.out.println("Window write : ");
		
	
	}

	public void run() {
	 			
		while(SimpleStream.isRunning && check!=true)
		{
			FromJSON(out);
			start++;
			//System.out.println("write");
			//System.out.println("Read Line1 : ");
		}
				
	
	}

	public void FromJSON(PrintWriter out) {
		if(start==0)
		{
			out.println(StartStream.ToJSON());
			out.flush();
			user = new UserKeyEnter();
			Thread userKeyEnter = new Thread(user);
			userKeyEnter.start();
		}
		//System.out.println(RemoteProcessRead.isAlive());
		else
		{
			check = user.getClose();
			
			if (RemoteProcessRead.isAlive()&&check!=true) {
				out.println(ImageStream.ToJSON(view,myViewer,frame));
				out.flush();
				try {
					Thread.sleep(rateLimit);
				} catch (InterruptedException e) {
					e.printStackTrace();
					System.exit(-1);
				}
			} else {
				//System.out.println("dsdfdass");
				out.println(StopStream.ToJSON());
				out.flush();
				frame.setVisible(false);
				//out.close();
				System.exit(0);
				/*try {
					
					out.close();
					socket.close();
					RemoteThread.threadsListRead.remove(Thread.currentThread());
					RemoteThread.threadsListWrite.remove(Thread.currentThread());
					
				} catch (IOException e) {
					System.out.println("Connection:2 "+e.getMessage());
				}*/
			}
		}
			
		
}
	

	

}
