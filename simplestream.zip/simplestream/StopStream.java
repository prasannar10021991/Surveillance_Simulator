/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;


import org.json.simple.JSONObject;

public class StopStream {

	static String type;

	StopStream() {
		type = "stopstream";
	}

	@SuppressWarnings("unchecked")
	public static String ToJSON() {
		type = "stopstream";
		JSONObject obj = new JSONObject();
		obj.put("type", type);
		return obj.toJSONString();
	}
}
