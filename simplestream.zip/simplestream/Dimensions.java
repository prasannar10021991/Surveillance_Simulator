/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */
package simplestream;

import java.io.PrintWriter;

import javax.swing.JFrame;


public class Dimensions implements Runnable {
	
	static int screen_width;
	static int screen_height;
	static int rateLimit;
	Viewer myViewer;
	
	static JFrame frame;	
	static PrintWriter out;
	static byte image_raw[];
	
	
	Dimensions(int width,int height,int rate)
	{
		screen_width = width;
		screen_height = height;
		rateLimit = rate;
		
		//frame = new JFrame("SimpleStream Read Viewer");
		//frame.setVisible(true);
		
	
		
	}

	@Override
	public void run() {
		
		
	}
	
	public int getWidth()
	{
		return screen_width;
	}
	public int getHeight()
	{
		return screen_height;
	}
	public int getRate()
	{
		return rateLimit;
	}

}
