/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;

import javax.swing.JFrame;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;

public class ImageStream {

	static String type;
	static String image;
	static JSONObject obj;
	static int screen_width ;
	static int screen_height;
	
	
	static byte image_raw[];

	ImageStream() {
		type = "image";
		
	}

	@SuppressWarnings("unchecked")
	public static String ToJSON(LocalView view,Viewer myViewer,JFrame frame) {
		type = "image";
		obj = new JSONObject();
		obj.put("type", type);
	
			image_raw = view.showImage();		
			//System.out.println(screen_width);
			myViewer.ViewerInput(image_raw,screen_width,screen_height);
			frame.repaint();
			
			byte compressed_image[] = Compressor.compress(image_raw);		
			image = Base64.encodeBase64String(compressed_image);
			//System.out.println(image);
			obj.put("data", image);
			return obj.toJSONString();
	
	}
	public static void setValues(int width,int height)
	{
		screen_width = width;
		screen_height = height;
	}
	}
