/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;


import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import java.util.StringTokenizer;

import javax.swing.JFrame;







import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;

public class SimpleStream {
	
	static Viewer myViewer;
	static int screen_width;
	static int screen_height;
	static JFrame frame;
	static int sport;
	static int rate;
	static byte image_raw[];
	static boolean isRunning = true;
	static ServerSocket serverSocket = null;
	static Socket clientSocket = null;
	static String hostname,remoteport;
	static int rport;
	static LocalView view = new LocalView();
	static StringTokenizer st,st2;
	static ArrayList<String> hostList = new ArrayList<String>();
	static ArrayList<String> portList = new ArrayList<String>();
	static int count =0;
	static int rcount =0;
	public static void main(String[] args) {
		
		CommandLineArgs arguments = new CommandLineArgs();
		CmdLineParser parser = new CmdLineParser(arguments);
		parser.setUsageWidth(80);
		try {
			parser.parseArgument(args);
		} catch (CmdLineException e) {
			System.err.println(e.getMessage());
			System.err.println("java -jar SimpleStreamer.jar [options...]");
			parser.printUsage(System.err);
			System.err.println();
			System.exit(1);
		}
		
		sport = arguments.getSport();
		hostname = arguments.getHost();
		if( hostname!=null){
		st = new StringTokenizer(hostname,",");
		
		 count = st.countTokens();
		}
		remoteport = arguments.getRemotePort();
		if( remoteport!=null){
		st2 = new StringTokenizer(remoteport,",");
		rcount = st2.countTokens();
		//System.out.println(count +" "+rcount);
		}
		if(hostname!=null)
		{
			if(count!=rcount)
			{
				System.out.println("Wrong inputs");
				System.exit(0);
			}
			else if(count>0)
			{
				while (st.hasMoreTokens())
				{
					
					String host = st.nextToken();
					
					hostList.add(host);
				}
				while (st2.hasMoreTokens())
				{
					String ports = st2.nextToken();
					portList.add(ports);
				}
			}
		}
		
		
		rate = arguments.getRate();
		screen_width = arguments.getWidth();
		screen_height =arguments.getHeight();
		
		/*myViewer = new Viewer();
		frame = new JFrame("SimpleStream Viewer");
		frame.setVisible(true);
		frame.setSize(screen_width, screen_height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(myViewer);*/
		
		
		
		System.out.println("sport :" +sport);
		//for(int i=0;i <hostname.size();i++){
		System.out.println("hostname :" +hostname);
		
		System.out.println("rport :" +remoteport);
		System.out.println("rate :" +rate);
		
		
		/*
		 *  Listening thread for other peers.
		 *  This peer does not connect to anyone 
		* 	but waiting for other peers for connections
		 */
		view.load(screen_width,screen_height);
		
		Thread stt = new Thread(new ClientThread(sport,view));
		stt.start();
		
		/* when there is a list of remote hosts which 
		* this peer trying to connect*/			
		if(hostname!=null)
		{	for(int i=0;i<hostList.size();i++)
			{
				String host = hostList.get(i);
				rport = Integer.parseInt(portList.get(i));
				//System.out.println(host+"  "+rport);
				Thread connectionThread = new Thread(new RemoteThread(rport, host,view));
				connectionThread.start();
				
			}
		}
		
			
				

			
		
	}

}
