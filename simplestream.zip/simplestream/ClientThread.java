/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;


import java.io.IOException;
import java.net.ServerSocket;
import java.util.LinkedList;

public class ClientThread implements Runnable{

	int serverPort;
	static ServerSocket listenSocket = null;
	LocalView view ;
	@SuppressWarnings("rawtypes")
	static LinkedList threadsListRead;
	@SuppressWarnings("rawtypes")
	static LinkedList threadsListWrite;
	@SuppressWarnings("rawtypes")
	static LinkedList clientsList;


	@SuppressWarnings("rawtypes")
	ClientThread(int sport,LocalView view2) {
		clientsList = new LinkedList();
		threadsListRead = new LinkedList();
		threadsListWrite = new LinkedList();
		serverPort = sport;
		view = view2;
	}

	@SuppressWarnings("unchecked")
	public synchronized void run() {
		try {
			listenSocket = new ServerSocket(serverPort);
		} catch (IOException e) {
			System.out.println("Listen socket: "+e.getMessage());
		}
		while (SimpleStream.isRunning)
			try {
				System.out.println("Peer listening for other peers' connections....");				
				java.net.Socket clientSocket = listenSocket.accept();
				System.out.println("Received connection" );
				threadsListRead.add(new Thread(new ClientProcessRead(clientSocket)));
				((Thread) threadsListRead.getLast()).start();
				threadsListWrite.add(new Thread(new ClientProcessWrite(clientSocket,view)));
				((Thread) threadsListWrite.getLast()).start();
				
			} catch (IOException e) {
				System.out.println("Listen socket : "+e.getMessage());
			}
	}
}
