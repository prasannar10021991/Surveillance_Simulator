/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */
package simplestream;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.net.Socket;

import javax.swing.JFrame;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ClientProcessRead implements Runnable {

	static Viewer myViewer;
	static int screen_width ;
	static int screen_height ;
	static JFrame frame;	
	static byte image_raw[];
	static boolean flag;	
	Socket clientSocket;
	int servingPort;
	int rateLimit;
	Hosts hostObject;
	public static Thread dim;
	public static Dimensions d;
	private static final JSONParser parser = new JSONParser();
	static BufferedReader in = null;
	
	ClientProcessRead(Socket s) {
		servingPort = 6262;
		clientSocket = s;
		flag=true;
		try {
			in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 	
		
	}

	public void run() {
		
		while (SimpleStream.isRunning) {			
		
			try {
				String data = in.readLine();
				FromJSON(data, in);
			} catch (IOException e) {
				return;
			}
		}
		
		
	}

	@SuppressWarnings("unchecked")
	public void FromJSON(String data,  BufferedReader in) {

		

			
			JSONObject obj = null;
			try {
				obj = (JSONObject) parser.parse(data);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			if (obj != null&&flag)
					if (obj.get("type").equals("startstream")){
						
						screen_width = Integer.parseInt(obj.get("width").toString());
						screen_height = Integer.parseInt(obj.get("height").toString());
						rateLimit = Integer.parseInt(obj.get("rateLimit").toString());
						//System.out.println(screen_width+" "+screen_height);
						d= new Dimensions(screen_width,screen_height,rateLimit);
						dim = new Thread(d);
						
						frame = new JFrame("SimpleStream Read Viewer");
						frame.setVisible(true);
						//System.out.println(d.getWidth()+"hhgfh "+d.getHeight());
						frame.setSize(d.getWidth(),d.getHeight());
						//System.out.println(frame.getSize());
						myViewer = new Viewer(d.getWidth(),d.getHeight());
						frame.setLocationRelativeTo(null);
						
						frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						frame.add(myViewer);
						
						
						hostObject = new Hosts(clientSocket.getInetAddress().getHostAddress(),servingPort);
					ClientThread.clientsList.add(hostObject);
						
					}
					else if(obj.get("type").equals("image"))
					{
						showFrame(obj.get("data").toString());
						//System.out.println("Read Line3 : "+ obj.get("data").toString());
						try {
							Thread.sleep(rateLimit);
						} catch (InterruptedException e) {
							e.printStackTrace();
							System.exit(-1);
						}
						return;
					}
					else if(obj.get("type").equals("stopstream"))
					{
						System.out.println("Connection Terminated");
						frame.setVisible(false);
						flag = false;
					}	
					
	}
	
	public void showFrame(String image) {		
	
		
		
		byte nobase64_image[] = Base64.decodeBase64(image);		
		image_raw = Compressor.decompress(nobase64_image);
		myViewer.ViewerInput(image_raw,d.getWidth(),d.getHeight());
		
		frame.repaint();
		
		
	}

	public static boolean isAlive() {
		if (flag==false)
			return false;
		else 
			return true;		
	}

}
