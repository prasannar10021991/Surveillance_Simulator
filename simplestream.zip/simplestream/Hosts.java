/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;

public class Hosts {

	String ipAddress;
	int sport;

	Hosts(String ip, int sport) {
		this.ipAddress = ip;
		this.sport = sport;
	}

	Hosts(String ip, String sport) {
		this.ipAddress = ip;
		this.sport = Integer.parseInt(sport);
	}

	public String getIP() {
		return ipAddress;
	}

	public String getPort() {
		return Integer.toString(sport);
	}

	

}
