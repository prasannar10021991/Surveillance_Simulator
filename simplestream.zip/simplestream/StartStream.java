/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;
import org.json.simple.JSONObject;

public class StartStream {
	static String type;

	StartStream() {
		type = "startstream";
	}

	@SuppressWarnings("unchecked")
	public static String ToJSON() {
		type = "startstream";
		JSONObject obj = new JSONObject();
		obj.put("type", type);
		obj.put("format", "raw");
		obj.put("width", Integer.toString(SimpleStream.screen_width));
		obj.put("height", Integer.toString(SimpleStream.screen_height));
		obj.put("rateLimit", Integer.toString(SimpleStream.rate));
		return obj.toJSONString();
	}

}
