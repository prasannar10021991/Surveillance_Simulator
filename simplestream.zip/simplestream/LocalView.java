/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;



import org.bridj.Pointer;

import com.github.sarxos.webcam.ds.buildin.natives.Device;
import com.github.sarxos.webcam.ds.buildin.natives.DeviceList;
import com.github.sarxos.webcam.ds.buildin.natives.OpenIMAJGrabber;

public class LocalView {
	
	private static OpenIMAJGrabber grabber;
	static int render;
	public void load(int width,int height) {
		grabber = new OpenIMAJGrabber();
		Device device = null;
		Pointer<DeviceList> devices = grabber.getVideoDevices();
		render  = (width*height*3);
		//System.out.println(width+" "+height+" "+render);
		for (Device d : devices.get().asArrayList()) {
			device = d;
			break;
			
		}
		boolean started = grabber.startSession(width,height,30D, Pointer.pointerTo(device));
		if (!started)

		throw new RuntimeException("Not able to start native grabber!");
		else
			return;
	}

	public byte[] showImage() {
		grabber.nextFrame();
		
		byte raw_image[] = grabber.getImage().getBytes(render);
		return raw_image;
		
	}

	public void stopSession() {
		grabber.stopSession();
	}
	
	

				
	}
	


