/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;


import org.kohsuke.args4j.Option;

public class CommandLineArgs {

	@Option(name = "-sport", aliases = { "--sp" },required = false,metaVar = "[-sport]",
            usage = "input server-port number")
	private int sport; // server port 
	
	@Option(name = "-width", aliases = { "--width" },required = false,metaVar = "[-width]",
            usage = "input webcam-screen width")
	private int screen_width;
	
	@Option(name = "-height", aliases = { "--height" },required = false,metaVar = "[-height]",
            usage = "input webcam-screen height")
	private int screen_height;
	
	/*@Option(name = "-remote", handler = StringArrayOptionHandler.class, required = false,
			metaVar = "[-remote hostname1, hostname2....]",usage = "input remote host name")
	private ArrayList<String> hostlist = new ArrayList<String>(); //remote server's IPs
	
	@Option(name = "-rport", handler = IntOptionHandler.class, required = false,metaVar = "[-rport Y1,Y2...]",
            usage = "input remote host port number")
	private ArrayList<Integer> rportList = new ArrayList<Integer>(); // remote server's port numbers
*/	
	@Option(name = "-remote", required = false,
			metaVar = "[-remote hostname...]",usage = "input remote host name")
	private String host; //remote server's IPs
	
	@Option(name = "-rport", required = false,metaVar = "[-rport Y1..]",
            usage = "input remote host port number")
	private String rport ; // remote server's port numbers
	
	@Option(name = "-rate", aliases = { "--rate" },required = false, metaVar = "[-frame_rate]",
            usage = "input rate limit")
	private int rate;
	
	public   CommandLineArgs() {
		sport = 6262;
		screen_width = 320;
		screen_height = 240;
		rate = 100;
	}
	
	public int getSport(){
		return sport;
	}
	
	public int getWidth() {
		return screen_width;
	}
	
	public int getHeight() {
		return screen_height;
	}
	
	/*public ArrayList<String> getHosts() {
		return hostlist;
	}
	
	public ArrayList<Integer> getRemotePorts() {
		return rportList;
	}*/
	
	public String getHost() {
		return host;
	}
	
	public String getRemotePort() {
		return rport;
	}
	
	public int getRate() {
		return rate;
	}
	
}
