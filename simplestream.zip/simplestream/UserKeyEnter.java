/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;

import java.util.Scanner;

public class UserKeyEnter implements Runnable {

	Scanner readUserInput;
	boolean close ;
	String keyin;
	UserKeyEnter() {
		close = false;
		keyin = null;
	}

	public void run() {
		readUserInput = new Scanner(System.in);
		keyin = readUserInput.nextLine();
		if (keyin != null)
		{
			close = true;
		}
			//RemoteHosts.out.println(StopStream.ToJSON());
	}
	public boolean getClose()
	{
		return close;
	}
}
