/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JFrame;


public class ClientProcessWrite implements Runnable {

	static boolean checkValue;
	Socket clientSocket;
	int servingPort;
	int rateLimit;
	Hosts hostObject;
	static Viewer myViewer;
	//static int screen_width;
	//static int screen_height;
	static JFrame frame;	
	static PrintWriter out;
	static byte image_raw[];
	LocalView view ;
	static UserKeyEnter user;

	ClientProcessWrite(Socket s,LocalView view2) {
		//servingPort = 6262;
		
		clientSocket = s;
	
		myViewer = new Viewer(SimpleStream.screen_width,SimpleStream.screen_height);
		frame = new JFrame("SimpleStream Write Viewer");
		frame.setVisible(true);
		//System.out.print(SimpleStream.screen_width+" "+ SimpleStream.screen_height);
		frame.setSize(SimpleStream.screen_width, SimpleStream.screen_height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(myViewer);
		view = view2;
		checkValue=false;
		ImageStream.setValues(SimpleStream.screen_width, SimpleStream.screen_height);
		rateLimit = ClientProcessRead.d.getRate();
		//System.out.print(rateLimit);
	}

	public void run() {
		if (SimpleStream.isRunning) {				
			try {				
			 	out = new PrintWriter(clientSocket.getOutputStream(), true);			 	
				
				FromJSON(out);
			} catch (IOException e) {
				System.out.println("Connection: "+e.getMessage());
			}
		}
	}

	public void FromJSON(PrintWriter out) {
			out.println(StartStream.ToJSON());
			out.flush();
			
			user = new UserKeyEnter();
			Thread stopStream = new Thread(user);
			stopStream.start();
			
			while (SimpleStream.isRunning)
			{
				checkValue = user.getClose();
				
				if (ClientProcessRead.isAlive() && checkValue!=true) {					
					out.println(ImageStream.ToJSON(view,myViewer,frame));
					out.flush();
					try {
						Thread.sleep(rateLimit);
					} catch (InterruptedException e) {
						e.printStackTrace();
						System.exit(-1);
					}
					
				} else if(checkValue){
					
						out.println(StopStream.ToJSON());
						frame.setVisible(false);
						out.flush();
						System.exit(0);
						//out.close();
						//clientSocket.close();
						/*ClientThread.clientsList.remove(hostObject);
						ClientThread.threadsListRead.remove(Thread.currentThread());
						ClientThread.threadsListWrite.remove(Thread.currentThread());*/
						
					
				}
				 else {
						
						out.println(StopStream.ToJSON());
						frame.setVisible(false);
						out.flush();
						//System.exit(0);
						//out.close();
						//clientSocket.close();
						/*ClientThread.clientsList.remove(hostObject);
						ClientThread.threadsListRead.remove(Thread.currentThread());
						ClientThread.threadsListWrite.remove(Thread.currentThread());*/
						
					
				}
				
			}
				
		
	}
}
