/*Prasanna Kumar Ravi - 667912
 * Gaganjot Kaur Khanna - 658614 */

package simplestream;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.net.Socket;

import java.util.LinkedList;

public class RemoteThread implements Runnable{

	int serverPort;
	String hostname;
	Socket s =null;
	static BufferedReader in;
	static PrintWriter out;
	static LocalView view;
	@SuppressWarnings("rawtypes")
	static LinkedList threadsListRead;
	@SuppressWarnings("rawtypes")
	static LinkedList threadsListWrite;
	


	@SuppressWarnings("rawtypes")
	RemoteThread(int rport, String rHost,LocalView view2) {
		threadsListRead = new LinkedList();
		threadsListWrite = new LinkedList();
		serverPort = rport;
		hostname = rHost;		
		view = view2;
		try {
			s = new Socket(hostname, serverPort);
			in = new BufferedReader(new InputStreamReader(s.getInputStream()));
			out = new PrintWriter(s.getOutputStream(), true);
			System.out.println("Connection Established");
		
		} catch (IOException e) {
			//System.out.println("Connection: "+e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public void run() {
		
	if (SimpleStream.isRunning)
	{
		threadsListWrite.add(new Thread(new RemoteProcessWrite(out,view)));
		((Thread) threadsListWrite.getLast()).start();
		threadsListRead.add(new Thread(new RemoteProcessRead(in,s)));
		
		((Thread) threadsListRead.getLast()).start();
		
	
	}
		
	}
}
