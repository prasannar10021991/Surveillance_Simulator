package au.edu.unimelb.atoosi.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Socket socket = null;
		try {
			int port = 3500;
			String host = "localhost";
			socket = new Socket(host, port);

			BufferedReader in = new BufferedReader(new InputStreamReader(
					socket.getInputStream()));
			PrintWriter out = new PrintWriter(socket.getOutputStream(),true);
			
			String line = null;
			Scanner input = new Scanner(System.in);
			System.out.println("Client connected.");
			do {
				System.out.print("Client: Type your message and enter:");
				line = input.nextLine();
				out.println(line);
				//out.flush();

				String str = in.readLine();
				System.out.println("Server:" + str);
			} while (!line.equals("END"));

			input.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (socket != null) {
				try {
					socket.close();
					System.out.println("Client disconneted.");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
