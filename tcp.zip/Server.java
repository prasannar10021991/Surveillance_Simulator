package au.edu.unimelb.atoosi.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ServerSocket serversocket = null;
		Socket socket = null;
		try {
			int port = 3500;
			serversocket = new ServerSocket(port);
			System.out.println("Server's listening...");
			while (true) {
				socket = serversocket.accept();
				System.out.println("Connected.");
				Thread con = new Connection(socket);
				con.start();
			}
			// out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (socket != null)
				try {
					socket.close();
					serversocket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

}
